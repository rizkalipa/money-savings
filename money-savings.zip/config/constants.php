<?php

return [
    'targetBalance' => 50000000
];
