<?php $__env->startSection('page_title', 'Money Savings | List Tabungan'); ?>

<?php $__env->startSection('title', 'List Tabungan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Data Tabungan</h3>
        </div>
        <div class="table-responsive">
            <table class="table card-table table-vcenter text-nowrap">
                <thead>
                <tr>
                    <th class="w-1">No.</th>
                    <th>Nama</th>
                    <th>Kredit</th>
                    <th>Debit</th>
                    <th>Persentase</th>
                    <th>Performa</th>
                    <th>Tanggal</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $savingHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-muted"><?php echo e($key + 1); ?></td>
                        <td><?php echo e($item->savings->user->name); ?></td>
                        <td><?php echo e($item->type == 'revenue' ? 'IDR ' . number_format($item->amount) : '-'); ?></td>
                        <td><?php echo e($item->type == 'expense' ? 'IDR ' . number_format($item->amount) : '-'); ?></td>
                        <td><?php echo e($item->saving_rate); ?>%</td>
                        <td>
                            <?php if($item->is_increase): ?>
                                <p class="text-success">
                                    <i class="fe fe-trending-up h-4"></i>
                                </p>
                            <?php else: ?>
                                <p class="text-warning">
                                    <i class="fe fe-trending-down h-4"></i>
                                </p>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(date('l, d F Y')); ?></td>
                        <td>
                            <form action="<?php echo e(''); ?>" method="POST" onsubmit="return isConfirm()">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-link text-danger" title="Delete">
                                    <i class="fe fe-trash-2"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-primary font-weight-bold">
                    <td colspan="2">Total</td>
                    <td>IDR <?php echo e(number_format($savingHistory->where('type', 'revenue')->sum('amount') - $savingHistory->where('type', 'expense')->sum('amount'))); ?></td>
                    <td>IDR <?php echo e(number_format($savingHistory->where('type', 'expense')->sum('amount'))); ?></td>
                    <td colspan="4"></td>
                </tr>
                </tbody>
            </table>

            <div class="card-body row">
                <div class="col-lg-12 d-flex justify-content-center">
                    <?php echo e($savingHistory->links('vendor.pagination.bootstrap-4')); ?>

                </div>
            </div>
        </div>

        <script>
            function isConfirm() {
                var response = confirm("Beneran mau hapus data ini ?")

                if (response) {
                    return true
                } else {
                    return false
                }
            }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\money-savings\resources\views/admin/list-saving.blade.php ENDPATH**/ ?>